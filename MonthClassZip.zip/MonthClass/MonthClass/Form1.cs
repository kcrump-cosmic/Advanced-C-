﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MonthClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public class Month
        {

            public int MonthNumber { get; }
            public string MonthName { get; }

            private static readonly string[] MonthNamesArray = CultureInfo.InvariantCulture.DateTimeFormat.MonthNames
                .TakeWhile(m => !string.IsNullOrEmpty(m)) // MonthNames array has an empty 13th element
                .ToArray();


            public Month() : this(1) { } // Calls the constructor that takes an int


            public Month(int monthNumber)
            {
                if (monthNumber < 1 || monthNumber > 12)
                {
                    MonthNumber = 1;
                }
                else
                {
                    MonthNumber = monthNumber;
                }
                MonthName = GetMonthName(MonthNumber);
            }

            public Month(string monthName)
            {
                MonthNumber = GetMonthNumber(monthName);
                MonthName = monthName; // Store the provided name or the default name if invalid
            }

            public Month(Month originalMonth)
            {
                MonthNumber = originalMonth.MonthNumber;
                MonthName = originalMonth.MonthName;
            }

            public override string ToString()
            {
                return MonthName;
            }

            public bool GreaterThan(Month otherMonth)
            {
                return MonthNumber > otherMonth.MonthNumber;
            }

            public bool LessThan(Month otherMonth)
            {
                return MonthNumber < otherMonth.MonthNumber;
            }

            private static string GetMonthName(int monthNumber)
            {
                if (monthNumber >= 1 && monthNumber <= 12)
                {
                    return MonthNamesArray[monthNumber - 1];
                }
                return MonthNamesArray[0]; // Default to "January"
            }

            private static int GetMonthNumber(string monthName)
            {
                for (int i = 0; i < MonthNamesArray.Length; i++)
                {
                    if (string.Equals(MonthNamesArray[i], monthName, StringComparison.OrdinalIgnoreCase))
                    {
                        return i + 1;
                    }
                }
                return 1; // Default to 1 (January) if not found
            }
        }
    }
}
