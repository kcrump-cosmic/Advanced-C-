﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarInstrumentSimulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        // The FuelGauge Class
        public class FuelGauge
        {
            private int gallons;
            private const int MAX_GALLONS = 15;

            public FuelGauge() { gallons = 0; }
            public FuelGauge(int f) { gallons = (f > MAX_GALLONS) ? MAX_GALLONS : f; }

            public int GetFuel() { return gallons; }

            public void IncrementFuel()
            {
                if (gallons < MAX_GALLONS) gallons++;
            }

            public void DecrementFuel()
            {
                if (gallons > 0) gallons--;
            }
        }

        // The Odometer Class
        public class Odometer
        {
            private int mileage;
            private const int MAX_MILEAGE = 999999;
            private const int MPG = 24;

            public Odometer(int m) { mileage = m; }

            public int GetMileage() { return mileage; }

            public void AddMileage(FuelGauge fuelGauge)
            {
                mileage++;
                if (mileage > MAX_MILEAGE) mileage = 0;

                // Burn fuel every 24 miles
                if (mileage % MPG == 0)
                {
                    fuelGauge.DecrementFuel();
                }
            }
        }

        // Demonstration Class
        class Program
        {
            static void Main()
            {
                FuelGauge fuel = new FuelGauge();
                Odometer odometer = new Odometer(0);

                // Fill up to 15 gallons
                for (int i = 0; i < 15; i++)
                {
                    fuel.IncrementFuel();
                }

                Console.WriteLine("Starting simulation...");

                // Loop until out of fuel
                while (fuel.GetFuel() > 0)
                {
                    odometer.AddMileage(fuel);
                    Console.WriteLine($"Mileage: {odometer.GetMileage()}, Fuel: {fuel.GetFuel()} gallons");
                }

                Console.WriteLine("Out of fuel!");
            }
        }
    }
}
