﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParkingTicketSimulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public class ParkedCar
        {
            public string Make { get; }
            public string Model { get; }
            public string Color { get; }
            public string LicenseNumber { get; }
            public int MinutesParked { get; }

            public ParkedCar(string make, string model, string color, string licenseNumber, int minutesParked)
            {
                Make = make;
                Model = model;
                Color = color;
                LicenseNumber = licenseNumber;
                MinutesParked = minutesParked;
            }
        }

        // The ParkingMeter Class
        public class ParkingMeter
        {
            public int MinutesPurchased { get; }

            public ParkingMeter(int minutesPurchased)
            {
                MinutesPurchased = minutesPurchased;
            }
        }

        // The ParkingTicket Class
        public class ParkingTicket
        {
            private ParkedCar _car;
            private string _officerName;
            private string _badgeNumber;
            public decimal Fine { get; private set; }

            public ParkingTicket(ParkedCar car, string officerName, string badgeNumber, int minutesPurchased)
            {
                _car = car;
                _officerName = officerName;
                _badgeNumber = badgeNumber;
                CalculateFine(car.MinutesParked, minutesPurchased);
            }

            private void CalculateFine(int parkedTime, int purchasedTime)
            {
                int extraMinutes = parkedTime - purchasedTime;
                if (extraMinutes <= 0)
                {
                    Fine = 0;
                }
                else
                {
                    // $25 for the first hour (or part), $10 for every additional hour (or part)
                    int hours = (int)Math.Ceiling((double)extraMinutes / 60);
                    Fine = 25 + (Math.Max(0, hours - 1) * 10);
                }
            }

            public void ReportTicket()
            {
                Console.WriteLine("\n--- PARKING TICKET ---");
                Console.WriteLine($"Car: {_car.Color} {_car.Make} {_car.Model} ({_car.LicenseNumber})");
                Console.WriteLine($"Fine: ${Fine}");
                Console.WriteLine($"Issued by: {_officerName} (Badge: {_badgeNumber})");
            }
        }

        // The PoliceOfficer Class
        public class PoliceOfficer
        {
            public string Name { get; }
            public string BadgeNumber { get; }

            public PoliceOfficer(string name, string badgeNumber)
            {
                Name = name;
                BadgeNumber = badgeNumber;
            }

            public ParkingTicket InspectCar(ParkedCar car, ParkingMeter meter)
            {
                if (car.MinutesParked > meter.MinutesPurchased)
                {
                    return new ParkingTicket(car, Name, BadgeNumber, meter.MinutesPurchased);
                }
                return null; // No ticket
            }
        }

        // Application Simulator
        class Program
        {
            static void Main(string[] args)
            {
                // 1. Create a Car (Make, Model, Color, License, MinutesParked)
                ParkedCar car = new ParkedCar("Toyota", "Corolla", "Red", "XYZ-123", 125);

                // 2. Create a Meter (Minutes Purchased)
                ParkingMeter meter = new ParkingMeter(60);

                // 3. Create a Police Officer
                PoliceOfficer officer = new PoliceOfficer("Officer Jones", "504");

                // 4. Officer Inspects Car
                ParkingTicket ticket = officer.InspectCar(car, meter);

                // 5. Issue Ticket if needed
                if (ticket != null)
                {
                    ticket.ReportTicket();
                }
                else
                {
                    Console.WriteLine("Car is legally parked.");
                }
            }
        }
    }
}
        